// pages/around/around.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    CustomBar: app.globalData.CustomBar,
    gridCol:3,
    iconList: [{
      icon: 'cardboardfill',
      color: 'red',
      badge: 0,
      name: '餐饮',
      amap:'050000'
    }, {
      icon: 'camerafill',
      color: 'orange',
      badge: 0,
      name: '风景',
      amap:'110000'
    }, {
      icon: 'read',
      color: 'yellow',
      badge: 0,
      name: '科教',
      amap:'140000'
    }, {
      icon: 'service',
      color: 'olive',
      badge: 0,
      name: '生活服务',
      amap:'070000'
    }, {
      icon: 'safe',
      color: 'cyan',
      badge: 0,
      name: '医疗',
      amap:'090000'
    }, {
      icon: 'cartfill',
      color: 'blue',
      badge: 0,
      name: '购物',
      amap:'060000'
    }, {
      icon: 'discoverfill',
      color: 'purple',
      badge: 0,
      name: '发现'
    }, {
      icon: 'questionfill',
      color: 'mauve',
      badge: 0,
      name: '帮助'
    }, {
      icon: 'commandfill',
      color: 'purple',
      badge: 0,
      name: '问答'
    }, {
      icon: 'brandfill',
      color: 'mauve',
      badge: 0,
      name: '版权'
    }],
  },

  navgeo:function(e){
    console.log("事件=",e)
    console.log("事件的数据=",e.currentTarget.dataset.title)
    wx.navigateTo({
      url: '/pages/geo/geo?name='+e.currentTarget.dataset.title+'&amap='+e.currentTarget.dataset.amap,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})