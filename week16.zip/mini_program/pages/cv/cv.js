// pages/cv/cv.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    redwine_result:""

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var that = this
    // 1. 获取access token
    wx.request({
      url: 'https://aip.baidubce.com/oauth/2.0/token', //仅为示例，并非真实的接口地址
      data: {
        grant_type:'client_credentials',
        client_id: 'gBCUZ8hvu6rMFKxIB6DDmu7p',
        client_secret:'uaU5BKCGePIERz4F8DFrwW33RytVjLLc'
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success (res) {
        console.log(res.data.access_token)

        // 2. 获取红酒图片识别数据
        wx.request({
          url: 'https://aip.baidubce.com/rest/2.0/image-classify/v1/redwine', //仅为示例，并非真实的接口地址

          //在此输入图片地址便可识别
          data: {
            access_token: res.data.access_token,
            url: 'https://img2.baidu.com/it/u=688224013,3424915736&fm=253&fmt=auto&app=120&f=JPEG?w=500&h=889'
          },

          header: {
            'Content-Type': 'application/x-www-form-urlencoded' // 默认值
          },
          method:'POST',
          success (res) {
            console.log(res.data)
            that.setData({
              redwine_result:res.data.result
            })
          }
        })
      }
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})