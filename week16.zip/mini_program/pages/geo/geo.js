// pages/geo/geo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    geo_around:"",
    title:""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    console.log("options=",options)
    that.setData({
      title:options.name
    })
    
    wx.request({
      url: 'https://restapi.amap.com/v3/place/around?parameters ', //仅为示例，并非真实的接口地址
      data: {
        key: 'b0121f143057c2f0c3607e48fe21bac9',
        location: '113.678280,23.628439',// 当前位置的经纬度
        types:options.amap
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success (res) {
        console.log(res.data) // console==>python中的print，打印出请求成功的数据
        that.setData({
          geo_around:res.data
        })  //将 response 响应数据存入 geo 页面的 data当中

      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})