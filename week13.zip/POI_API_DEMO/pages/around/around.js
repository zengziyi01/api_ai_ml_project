// pages/around/around.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    iconList: [{
      icon: 'shop',
      color: 'red',
      badge: 0,
      name: '餐饮'
    }, {
      icon: 'recordfill',
      color: 'orange',
      badge: 0,
      name: '风景'
    }, {
      icon: 'read',
      color: 'yellow',
      badge: 0,
      name: '科教'
    }, {
      icon: 'service',
      color: 'olive',
      badge: 0,
      name: '生活服务'
    }, {
      icon: 'safe',
      color: 'cyan',
      badge: 0,
      name: '医疗'
    }, {
      icon: 'cart',
      color: 'blue',
      badge: 0,
      name: '购物'
    }, {
      icon: 'discoverfill',
      color: 'purple',
      badge: 0,
      name: '发现'
    }, {
      icon: 'questionfill',
      color: 'mauve',
      badge: 0,
      name: '帮助'
    }, {
      icon: 'commandfill',
      color: 'purple',
      badge: 0,
      name: '问答'
    }, {
      icon: 'brandfill',
      color: 'mauve',
      badge: 0,
      name: '版权'
    }],
    gridCol:3,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})